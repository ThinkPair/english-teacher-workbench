'use strict';

const core = require('../../lib/core.js');
const KEYS = {
  demo: 'student-manager-lite.v1.demo',
  personal: 'student-manager-lite.v1.personal'
};
const TYPES = [
  { key: 'weak', label: '薄弱知识点', hint: '记录还需练习的具体内容', tone: 'amber' },
  { key: 'strong', label: '强项知识点', hint: '记录可继续发挥的长处', tone: 'green' },
  { key: 'habit', label: '学习习惯', hint: '记录课堂与练习中的观察', tone: 'purple' }
];
const clone = value => JSON.parse(JSON.stringify(value));
const byDate = field => (a, b) => b[field].localeCompare(a[field]);
const labelFor = space => space === 'personal' ? '正式档案' : '示例空间';
const rate = score => Math.round(score.score / score.total * 1000) / 10;
const safeMessage = error => error && error.message ? error.message : '操作未完成，请稍后重试。';
// Leave headroom under WeChat's 1 MB limit per storage key.
const MAX_NATIVE_BYTES = 900 * 1024;
const utf8Bytes = text => {
  let bytes = 0;
  for (const char of text) {
    const point = char.codePointAt(0);
    bytes += point <= 0x7f ? 1 : point <= 0x7ff ? 2 : point <= 0xffff ? 3 : 4;
  }
  return bytes;
};

Page({
  data: {
    space: 'demo', spaceLabel: '示例空间', view: 'list', detailTab: 'scores',
    query: '', rows: [], stats: { students: 0, scores: 0, todo: 0 },
    student: null, scores: [], chart: [], tagGroups: [], plans: [], ideas: [],
    error: '', notice: '', blocked: false, canCopyRaw: false,
    form: {}, formKind: '', formTitle: '', formStudentName: '', formIsEdit: false,
    typeNames: TYPES.map(type => type.label), typeIndex: 0,
    importText: '', importPreview: null, importConfirmed: false
  },

  onLoad() {
    this._db = null;
    this._space = 'demo';
    this._diskToken = null;
    this._raw = undefined;
    this._draftContext = null;
    this._dirty = false;
    this._loadSpace('demo');
  },

  _readDisk(space) {
    const info = wx.getStorageInfoSync();
    if (!info || !Array.isArray(info.keys)) throw new Error('暂时无法读取本地档案，请重新读取。');
    const present = info.keys.indexOf(KEYS[space]) !== -1;
    const raw = present ? wx.getStorageSync(KEYS[space]) : undefined;
    return { present, raw, token: present ? 'stored:' + JSON.stringify(raw) : 'missing' };
  },

  _loadSpace(space) {
    if (!KEYS[space]) return;
    let disk;
    try { disk = this._readDisk(space); }
    catch (error) {
      this.setData({ error: '无法读取本地档案；没有改动已有记录。请重试。', notice: '' });
      if (!this._db) this.setData({ blocked: true, view: 'backup' });
      return;
    }
    let db;
    try {
      db = disk.present
        ? (typeof disk.raw === 'string' ? core.importDatabase(disk.raw) : core.validateDatabase(disk.raw))
        : core.createDatabase(space === 'demo');
    } catch (error) {
      this._db = null;
      this._space = space;
      this._diskToken = disk.token;
      this._raw = disk.raw;
      this._draftContext = null;
      this._dirty = false;
      this._resetImport();
      this.setData({
        space, spaceLabel: labelFor(space), blocked: true, view: 'backup',
        canCopyRaw: true, student: null, rows: [], scores: [], chart: [], plans: [], ideas: [], tagGroups: [],
        stats: { students: 0, scores: 0, todo: 0 },
        error: '这份档案暂时无法打开：' + safeMessage(error) + '。原内容已保留，请先备份再恢复。', notice: ''
      });
      return;
    }
    if (!disk.present) {
      try {
        const text = core.exportDatabase(db);
        wx.setStorageSync(KEYS[space], text);
        disk = { present: true, raw: text, token: 'stored:' + JSON.stringify(text) };
      } catch (error) {
        this.setData({ error: '本地空间暂时无法保存，尚未切换或建立新档案。请检查设备存储后重试。', notice: '' });
        if (!this._db) this.setData({ blocked: true, view: 'backup' });
        return;
      }
    }
    this._db = db;
    this._space = space;
    this._diskToken = disk.token;
    this._raw = disk.raw;
    this._draftContext = null;
    this._dirty = false;
    this._resetImport();
    this.setData({
      space, spaceLabel: labelFor(space), blocked: false, canCopyRaw: false,
      view: 'list', query: '', student: null, error: '', notice: ''
    });
    this._render();
  },

  _checkDisk(expectedSpace) {
    if (this._space !== expectedSpace) throw new Error('当前空间已变化，请返回后重新操作。');
    const disk = this._readDisk(expectedSpace);
    if (disk.token !== this._diskToken) {
      throw new Error('档案已发生变化，本次没有覆盖。请先保存未提交的文字，再到备份与恢复中重新读取档案。');
    }
  },

  _writeDatabase(next, expectedSpace) {
    const clean = core.validateDatabase(next);
    const text = core.exportDatabase(clean);
    if (utf8Bytes(text) > MAX_NATIVE_BYTES) {
      throw new Error('当前空间的档案已接近本地容量上限，本次没有保存。请先导出备份，再整理旧记录后重试。');
    }
    this._checkDisk(expectedSpace);
    try { wx.setStorageSync(KEYS[expectedSpace], text); }
    catch (error) { throw new Error('保存失败，已有档案没有改变。请检查设备存储空间，保留本次填写内容后重试。'); }
    // Publish state only after the synchronous storage write succeeds.
    this._db = clean;
    this._raw = text;
    this._diskToken = 'stored:' + JSON.stringify(text);
    this.setData({ blocked: false, canCopyRaw: false, error: '' });
    this._render();
  },

  _render() {
    if (!this._db) return;
    const db = this._db;
    const query = this.data.query.trim().toLowerCase();
    const rows = db.students.filter(student =>
      [student.name, student.grade, student.className].join(' ').toLowerCase().indexOf(query) !== -1
    ).map(student => {
      const scores = db.scores.filter(score => score.studentId === student.id).sort(byDate('date'));
      return Object.assign({}, student, {
        initial: Array.from(student.name)[0] || '学',
        latest: scores.length ? rate(scores[0]) + '%' : '待记录',
        latestLabel: scores.length ? scores[0].title : '还没有成绩',
        todo: db.plans.filter(plan => plan.studentId === student.id && plan.status === 'todo').length
      });
    });
    const selectedId = this.data.student && this.data.student.id;
    const student = db.students.find(item => item.id === selectedId) || null;
    let scores = [], chart = [], tagGroups = [], plans = [], ideas = [];
    if (student) {
      scores = db.scores.filter(item => item.studentId === student.id).sort(byDate('date'))
        .map(item => Object.assign({}, item, { rate: rate(item) }));
      chart = scores.slice(0, 8).reverse().map(item => Object.assign({}, item, { shortDate: item.date.slice(5) }));
      tagGroups = TYPES.map(type => {
        const tags = db.tags.filter(item => item.studentId === student.id && item.type === type.key)
          .sort((a, b) => (a.status === b.status ? b.observedOn.localeCompare(a.observedOn) : a.status === 'active' ? -1 : 1));
        return Object.assign({}, type, { tags, activeCount: tags.filter(item => item.status === 'active').length });
      });
      plans = db.plans.filter(item => item.studentId === student.id).map(item => Object.assign({}, item, {
        isOverdue: item.status === 'todo' && !!item.dueDate && item.dueDate < core.today()
      })).sort((a, b) => {
        if (a.status !== b.status) return a.status === 'todo' ? -1 : 1;
        return (a.dueDate || '9999').localeCompare(b.dueDate || '9999');
      });
      ideas = core.suggestions(db, student.id);
    }
    this.setData({ rows, student, scores, chart, tagGroups, plans, ideas,
      stats: { students: db.students.length, scores: db.scores.length, todo: db.plans.filter(item => item.status === 'todo').length }
    });
  },

  _confirm(title, content, confirmText) {
    return new Promise(resolve => wx.showModal({
      title, content, confirmText: confirmText || '确认', cancelText: '取消', confirmColor: '#1b6b51',
      success: result => resolve(!!result.confirm), fail: () => resolve(false)
    }));
  },

  async _leaveDraft() {
    if (this.data.view === 'form' && this._dirty) {
      if (!await this._confirm('放弃本次修改？', '尚未保存的内容会丢失，已有档案不受影响。', '放弃修改')) return false;
    }
    return true;
  },

  _closeDraft() {
    this._draftContext = null;
    this._dirty = false;
  },

  async onSwitchSpace(event) {
    const space = event.currentTarget.dataset.space;
    if (!KEYS[space] || (space === this._space && !this.data.blocked)) return;
    if (await this._leaveDraft()) this._loadSpace(space);
  },

  onSearch(event) { this.setData({ query: event.detail.value }); this._render(); },

  async onHome() {
    if (await this._leaveDraft()) {
      this._closeDraft();
      this.setData({ view: this.data.blocked ? 'backup' : 'list', error: '', notice: '' });
    }
  },

  async onBackup() {
    if (await this._leaveDraft()) {
      this._closeDraft();
      this.setData({ view: 'backup', error: '', notice: '' });
    }
  },

  onOpenStudent(event) {
    if (!this._db) return;
    const student = this._db.students.find(item => item.id === event.currentTarget.dataset.id);
    if (!student) return;
    this.setData({ student, view: 'detail', detailTab: 'scores', error: '', notice: '' });
    this._render();
  },

  onTab(event) {
    const tab = event.currentTarget.dataset.tab;
    if (['scores', 'tags', 'plans', 'ideas'].indexOf(tab) !== -1) this.setData({ detailTab: tab, error: '', notice: '' });
  },

  _openForm(kind, record, options) {
    if (!this._db) return;
    options = options || {};
    const student = this.data.student;
    if (kind !== 'student' && !student) return;
    let form;
    if (record) form = clone(record);
    else if (kind === 'student') form = { name: '', grade: '', className: '', note: '' };
    else if (kind === 'score') form = { title: '', date: core.today(), score: '', total: '', note: '' };
    else if (kind === 'tag') form = { type: options.type || 'weak', label: '', note: '', observedOn: core.today(), status: 'active' };
    else form = { title: '', body: '', dueDate: '', status: 'todo', result: '', sourceEvidence: [] };
    if (options.idea) {
      form.title = options.idea.title;
      form.body = options.idea.body;
      form.sourceEvidence = options.idea.evidence.slice();
    }
    this._draftContext = {
      space: this._space, revision: this._db.revision,
      studentId: kind === 'student' ? (record ? record.id : null) : student.id,
      recordId: record ? record.id : null,
      returnTab: this.data.detailTab,
      returnView: this.data.view === 'list' ? 'list' : 'detail'
    };
    this._dirty = !!options.idea;
    const names = { student: '学员档案', score: '成绩', tag: '观察标签', plan: '跟进计划', complete: '完成记录' };
    this.setData({
      view: 'form', form, formKind: kind,
      formTitle: kind === 'complete' ? '记录跟进结果' : (record ? '编辑' : '新增') + names[kind],
      formStudentName: student && kind !== 'student' ? student.name : '', formIsEdit: !!record,
      typeIndex: Math.max(0, TYPES.findIndex(type => type.key === form.type)), error: '', notice: ''
    });
    wx.pageScrollTo({ scrollTop: 0, duration: 0 });
  },

  onAddStudent() { this._openForm('student'); },
  onEditStudent() { if (this.data.student) this._openForm('student', this.data.student); },
  onAddScore() { this._openForm('score'); },
  onAddTag(event) { this._openForm('tag', null, { type: event.currentTarget.dataset.type || 'weak' }); },
  onAddPlan() { this._openForm('plan'); },

  onEditRecord(event) {
    if (!this._db || !this.data.student) return;
    const kind = event.currentTarget.dataset.kind;
    const table = { score: 'scores', tag: 'tags', plan: 'plans', complete: 'plans' }[kind];
    if (!table) return;
    const record = this._db[table].find(item => item.id === event.currentTarget.dataset.id && item.studentId === this.data.student.id);
    if (record) this._openForm(kind, record);
  },

  onUseIdea(event) {
    const idea = this.data.ideas.find(item => item.key === event.currentTarget.dataset.key);
    if (idea) this._openForm('plan', null, { idea });
  },

  onFieldInput(event) {
    const field = event.currentTarget.dataset.field;
    if (['name', 'grade', 'className', 'note', 'title', 'date', 'score', 'total', 'label', 'observedOn', 'body', 'dueDate', 'result'].indexOf(field) === -1) return;
    this._dirty = true;
    this.setData({ ['form.' + field]: event.detail.value, error: '' });
  },

  onTagType(event) {
    const index = Number(event.detail.value);
    if (!TYPES[index]) return;
    this._dirty = true;
    this.setData({ typeIndex: index, 'form.type': TYPES[index].key, error: '' });
  },

  onClearDueDate() { this._dirty = true; this.setData({ 'form.dueDate': '' }); },

  async onCancelForm() {
    const context = this._draftContext;
    if (!await this._leaveDraft()) return;
    this._closeDraft();
    this.setData({ view: context ? context.returnView : 'list', error: '', notice: '' });
  },

  onSaveForm() {
    const context = this._draftContext;
    if (!context || !this._db) return;
    try {
      if (context.space !== this._space || context.revision !== this._db.revision) throw new Error('档案已变化，请返回后重新打开这条记录。');
      const kind = this.data.formKind;
      const input = clone(this.data.form);
      delete input.id;
      delete input.studentId;
      if (context.recordId) input.id = context.recordId;
      if (kind !== 'student') input.studentId = context.studentId;
      if (kind === 'complete') input.status = 'done';
      const save = { student: core.saveStudent, score: core.saveScore, tag: core.saveTag, plan: core.savePlan, complete: core.savePlan }[kind];
      const next = save(this._db, input);
      this._writeDatabase(next, context.space);
      this._draftContext = null;
      this._dirty = false;
      const detailTab = { score: 'scores', tag: 'tags', plan: 'plans', complete: 'plans' }[kind] || context.returnTab;
      this.setData({ view: context.returnView, detailTab, notice: '已保存到' + labelFor(context.space), error: '' });
      this._render();
    } catch (error) { this.setData({ error: safeMessage(error), notice: '' }); }
  },

  async onDeleteStudent() {
    if (!this._db || !this.data.student) return;
    const student = clone(this.data.student), space = this._space, revision = this._db.revision;
    const n = table => this._db[table].filter(item => item.studentId === student.id).length;
    const text = '将删除“' + student.name + '”及其 ' + n('scores') + ' 条成绩、' + n('tags') + ' 个标签、' + n('plans') + ' 条计划。删除后只能通过已有备份恢复。';
    if (!await this._confirm('删除这位学员？', text, '确认删除')) return;
    try {
      if (!this._db || space !== this._space || revision !== this._db.revision) throw new Error('档案已变化，请重新确认删除范围。');
      this._writeDatabase(core.deleteStudent(this._db, student.id), space);
      this.setData({ student: null, view: 'list', notice: '学员及关联记录已删除', error: '' });
    } catch (error) { this.setData({ error: safeMessage(error) }); }
  },

  async onDeleteRecord(event) {
    if (!this._db || !this.data.student) return;
    const kind = event.currentTarget.dataset.kind, id = event.currentTarget.dataset.id;
    const table = { score: 'scores', tag: 'tags', plan: 'plans' }[kind];
    if (!table) return;
    const record = this._db[table].find(item => item.id === id && item.studentId === this.data.student.id);
    if (!record) return;
    const space = this._space, revision = this._db.revision;
    if (!await this._confirm('删除这条记录？', '“' + (record.title || record.label) + '”将从当前档案中删除。已保存计划中的依据快照会保留。', '确认删除')) return;
    try {
      if (!this._db || space !== this._space || revision !== this._db.revision) throw new Error('档案已变化，请重新确认。');
      const remove = { score: core.deleteScore, tag: core.deleteTag, plan: core.deletePlan }[kind];
      this._writeDatabase(remove(this._db, id), space);
      this.setData({ notice: '记录已删除', error: '' });
    } catch (error) { this.setData({ error: safeMessage(error) }); }
  },

  async onToggleTag(event) {
    if (!this._db || !this.data.student) return;
    const tag = this._db.tags.find(item => item.id === event.currentTarget.dataset.id && item.studentId === this.data.student.id);
    if (!tag) return;
    const space = this._space, revision = this._db.revision, next = clone(tag);
    next.status = tag.status === 'active' ? 'resolved' : 'active';
    if (!await this._confirm(next.status === 'resolved' ? '解除当前标签？' : '恢复当前标签？',
      next.status === 'resolved' ? '观察记录会保留，后续建议不再把它作为当前标签。这不等于系统判断学员已掌握。' : '这条观察会重新用于生成建议，请确认它仍符合现状。', '确认')) return;
    try {
      if (!this._db || space !== this._space || revision !== this._db.revision) throw new Error('档案已变化，请重新确认。');
      this._writeDatabase(core.saveTag(this._db, next), space);
      this.setData({ notice: next.status === 'resolved' ? '标签已解除，观察记录仍保留' : '标签已恢复', error: '' });
    } catch (error) { this.setData({ error: safeMessage(error) }); }
  },

  async onReopenPlan(event) {
    if (!this._db || !this.data.student) return;
    const plan = this._db.plans.find(item => item.id === event.currentTarget.dataset.id && item.studentId === this.data.student.id);
    if (!plan) return;
    const space = this._space, revision = this._db.revision, next = clone(plan);
    if (!await this._confirm('重新跟进这项计划？', '计划将回到待跟进，已有结果会保留，可继续修改。', '重新跟进')) return;
    try {
      if (!this._db || space !== this._space || revision !== this._db.revision) throw new Error('档案已变化，请重新确认。');
      next.status = 'todo';
      this._writeDatabase(core.savePlan(this._db, next), space);
      this.setData({ notice: '已恢复为待跟进', error: '' });
    } catch (error) { this.setData({ error: safeMessage(error) }); }
  },

  async onExport() {
    if (!this._db) return;
    const space = this._space;
    let text;
    try { this._checkDisk(space); text = core.exportDatabase(this._db); }
    catch (error) { this.setData({ error: safeMessage(error) }); return; }
    if (!await this._confirm('复制完整档案备份？', '将把' + labelFor(space) + '的全部学员、成绩、标签和计划复制到系统剪贴板，可能含个人信息。请只粘贴到你信任的私人位置，勿发到群聊或公开文档。', '确认复制')) return;
    wx.setClipboardData({
      data: text,
      success: () => this.setData({ notice: labelFor(space) + '备份已复制。请在私人位置粘贴保存；剪贴板本身不是持久备份。', error: '' }),
      fail: () => this.setData({ error: '复制未完成，档案没有改变。请重试。', notice: '' })
    });
  },

  async onCopyRaw() {
    if (!this.data.canCopyRaw || this._raw === undefined) return;
    const text = typeof this._raw === 'string' ? this._raw : JSON.stringify(this._raw);
    if (!await this._confirm('复制暂时无法打开的原内容？', '原内容可能包含全部学员信息。复制仅用于私人保留或排查，不代表它已经是可恢复的有效备份。请勿公开。', '确认复制')) return;
    wx.setClipboardData({ data: text,
      success: () => this.setData({ notice: '原内容已复制，请另存于私人位置。当前档案未被改动。' }),
      fail: () => this.setData({ error: '复制失败，原内容仍保留在本地。' })
    });
  },

  _resetImport() {
    this._importDb = null;
    this._importTextSnapshot = null;
    this.setData({ importText: '', importPreview: null, importConfirmed: false });
  },

  onImportInput(event) {
    this._importDb = null;
    this._importTextSnapshot = null;
    this.setData({ importText: event.detail.value, importPreview: null, importConfirmed: false, error: '', notice: '' });
  },

  onCheckImport() {
    try {
      const db = core.importDatabase(this.data.importText);
      this._importDb = db;
      this._importTextSnapshot = this.data.importText;
      this.setData({ importPreview: {
        students: db.students.length, scores: db.scores.length, tags: db.tags.length, plans: db.plans.length,
        currentStudents: this._db ? this._db.students.length : '无法读取'
      }, importConfirmed: false, error: '', notice: '备份格式检查通过，尚未恢复。请核对所属空间与数量。' });
    } catch (error) {
      this._importDb = null;
      this.setData({ importPreview: null, importConfirmed: false, error: '未恢复：' + safeMessage(error), notice: '' });
    }
  },

  onImportAgree(event) { this.setData({ importConfirmed: event.detail.value.indexOf('replace') !== -1 }); },

  async onApplyImport() {
    if (!this._importDb || this._importTextSnapshot !== this.data.importText || !this.data.importConfirmed) {
      this.setData({ error: '请先检查备份，并确认完整替换当前空间。' }); return;
    }
    const space = this._space, token = this._diskToken;
    const next = clone(this._importDb);
    next.revision = this._db ? this._db.revision + 1 : 1;
    const count = next.students.length;
    if (!await this._confirm('完整替换' + labelFor(space) + '？',
      '恢复后当前空间将变为备份里的 ' + count + ' 位学员及关联记录，现有内容不会合并。若还未导出原档案，请取消并先备份。另一空间不受影响。', '确认替换')) return;
    try {
      if (space !== this._space || token !== this._diskToken) throw new Error('当前档案已变化，请重新检查备份。');
      this._writeDatabase(next, space);
      this._resetImport();
      this.setData({ student: null, view: 'list', query: '', notice: '已恢复到' + labelFor(space) + '，请核对学员与记录。', error: '' });
      this._render();
    } catch (error) { this.setData({ error: safeMessage(error), notice: '' }); }
  },

  async onReload() {
    if (!await this._confirm('重新读取本地档案？', '将读取设备当前保存的内容。未提交的导入文字会清空；已保存的记录不会被删除。', '重新读取')) return;
    this._loadSpace(this._space);
  }
});
